from flask import Blueprint, jsonify, request
from app.models.cardapio_model import CardapioModel

cardapio_bp = Blueprint('cardapio', __name__)

# Endpoint GET para listar os itens do cardápio
@cardapio_bp.route('/api/cardapio', methods=['GET'])
def get_cardapio():
    pratos = CardapioModel.listar_todos()
    return jsonify({
        "sucesso": True,
        "dados": pratos
    }), 200

# Endpoint GET para buscar um prato específico
@cardapio_bp.route('/api/cardapio/<int:prato_id>', methods=['GET'])
def get_prato(prato_id):
    prato = CardapioModel.buscar_por_id(prato_id)
    if prato:
        return jsonify({"sucesso": True, "dados": prato}), 200
    return jsonify({"sucesso": False, "mensagem": "Prato não encontrado"}), 404