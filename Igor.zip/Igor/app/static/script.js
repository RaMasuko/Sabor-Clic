// Estado da aplicação em memória (3º Bimestre - JS)
const estadoApp = {
    cardapio: [],
    carrinho: []
};

// 1. BUCA DE DADOS (Integração Fetch API com Flask)
async function carregarCardapio() {
    try {
        const resposta = await fetch('/api/cardapio');
        
        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const resultado = await resposta.json();

        if (resultado.sucesso) {
            // Guarda no estado em memória
            estadoApp.cardapio = resultado.dados;
            
            // Renderiza na interface
            renderizarCardapio(estadoApp.cardapio);
        } else {
            console.error("Erro na API:", resultado.mensagem);
        }
    } catch (erro) {
        console.error("Falha ao carregar cardápio:", erro);
        const container = document.getElementById('cardapio-container');
        if (container) {
            container.innerHTML = `<p class="erro">Erro ao carregar o cardápio. Tente novamente.</p>`;
        }
    }
}

// 2. MANIPULAÇÃO DINÂMICA DO DOM (Cardápio / Design)
function renderizarCardapio(pratos) {
    const container = document.getElementById('cardapio-container');
    if (!container) return;

    container.innerHTML = '';

    // Uso de for...of conforme requisito do 3º bimestre
    for (const prato of pratos) {
        const card = document.createElement('div');
        card.className = 'card-prato';
        
        card.innerHTML = `
            <h3>${sanitizarTexto(prato.nome)}</h3>
            <p>Preço: R$ ${prato.preco.toFixed(2)}</p>
            <button onclick="adicionarAoCarrinho(${prato.id})">Adicionar ao Pedido</button>
        `;
        
        container.appendChild(card);
    }
}

// 3. REGRA DE NEGÓCIO E CÁLCULO EM MEMÓRIA (Carrinho)
function adicionarAoCarrinho(pratoId) {
    const prato = estadoApp.cardapio.find(item => item.id === pratoId);
    if (!prato) return;

    const itemExistente = estadoApp.carrinho.find(item => item.id === pratoId);

    if (itemExistente) {
        itemExistente.quantidade += 1;
    } else {
        estadoApp.carrinho.push({ ...prato, quantidade: 1 });
    }

    atualizarResumoCarrinho();
}

function atualizarResumoCarrinho() {
    // Uso do método funcional reduce para calcular o subtotal
    const total = estadoApp.carrinho.reduce((acc, item) => acc + (item.preco * item.quantidade), 0);
    
    const elementoTotal = document.getElementById('total-carrinho');
    if (elementoTotal) {
        elementoTotal.textContent = `Total: R$ ${total.toFixed(2)}`;
    }

    console.log("Carrinho Atualizado:", estadoApp.carrinho);
}

// 4. SEGURANÇA E VALIDAÇÃO (Item 5.5 - Prevenção de Injeção Básica)
function sanitizarTexto(texto) {
    const div = document.createElement('div');
    div.textContent = texto;
    return div.innerHTML;
}

// Inicialização ao carregar o DOM
document.addEventListener('DOMContentLoaded', () => {
    carregarCardapio();
});