PRATOS = [
    {"id": 1, "nome": "Hambúrguer Gourmet", "preco": 32.90, "ativo": True},
    {"id": 2, "nome": "Massa ao Pesto", "preco": 28.50, "ativo": True}
]

class CardapioModel:
    @staticmethod
    def listar_todos():
        return [prato for prato in PRATOS if prato["ativo"]]

    @staticmethod
    def buscar_por_id(prato_id):
        return next((p for p in PRATOS if p["id"] == prato_id), None)