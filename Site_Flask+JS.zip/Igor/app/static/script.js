const estadoApp = {
    cardapio: [],
    carrinho: []
};

async function carregarCardapio() {
    try {
        const resposta = await fetch('/api/cardapio');
        
        if (!resposta.ok) {
            throw new Error(`Erro HTTP: ${resposta.status}`);
        }

        const resultado = await resposta.json();

        if (resultado.sucesso) {
            estadoApp.cardapio = resultado.dados;
            
            renderizarCardapio(estadoApp.cardapio);
        } else {
            console.error("Erro na API:", resultado.mensagem);
        }
    } catch (erro) {
        console.error("Falha ao carregar cardápio:", erro);
        const container = document.getElementById('cardapio-container');
        if (container) {
            container.innerHTML = `<p class="erro">Erro ao carregar o cardápio. Tente novamente.</p>`;
        }
    }
}

function renderizarCardapio(pratos) {
    const container = document.getElementById('cardapio-container');
    if (!container) return;

    container.innerHTML = '';

    for (const prato of pratos) {
        const card = document.createElement('div');
        card.className = 'card-prato';
        
        card.innerHTML = `
            <h3>${sanitizarTexto(prato.nome)}</h3>
            <p>Preço: R$ ${prato.preco.toFixed(2)}</p>
            <button onclick="adicionarAoCarrinho(${prato.id})">Adicionar ao Pedido</button>
        `;
        
        container.appendChild(card);
    }
}

function validarFormularioCliente(evento) {
    evento.preventDefault();

    const nome =
        document.getElementById("nome").value.trim();

    const email =
        document.getElementById("email").value.trim();

    const mensagem =
        document.getElementById("mensagem-cliente");

    if (nome === "") {
        mensagem.textContent =
            "Informe o nome do cliente.";

        return;
    }

    if (
        email === ""
        || !email.includes("@")
    ) {
        mensagem.textContent =
            "Informe um e-mail válido.";

        return;
    }

    mensagem.textContent =
        "Dados validados com sucesso.";
}

function adicionarAoCarrinho(pratoId) {
    const prato = estadoApp.cardapio.find(item => item.id === pratoId);
    if (!prato) return;

    const itemExistente = estadoApp.carrinho.find(item => item.id === pratoId);

    if (itemExistente) {
        itemExistente.quantidade += 1;
    } else {
        estadoApp.carrinho.push({ ...prato, quantidade: 1 });
    }

    atualizarResumoCarrinho();
}

function atualizarResumoCarrinho() {
    const listaCarrinho =
        document.getElementById("itens-carrinho");

    const elementoTotal =
        document.getElementById("total-carrinho");

    listaCarrinho.innerHTML = "";

    for (const item of estadoApp.carrinho) {
        const subtotal =
            item.preco * item.quantidade;

        const linha = document.createElement("li");

        linha.textContent =
            `${item.nome} - ` +
            `${item.quantidade} unidade(s) - ` +
            `Subtotal: R$ ${subtotal.toFixed(2)}`;

        listaCarrinho.appendChild(linha);
    }

    const total = estadoApp.carrinho.reduce(
        (acumulador, item) => {
            return acumulador +
                (item.preco * item.quantidade);
        },
        0
    );

    elementoTotal.textContent =
        `Total: R$ ${total.toFixed(2)}`;
}

function sanitizarTexto(texto) {
    const div = document.createElement('div');
    div.textContent = texto;
    return div.innerHTML;
}

function finalizarPedido() {
    const mensagem =
        document.getElementById("mensagem-pedido");

    if (estadoApp.carrinho.length === 0) {
        mensagem.textContent =
            "Adicione pelo menos um prato ao carrinho.";

        return;
    }

    const valorTotal = estadoApp.carrinho.reduce(
        (total, item) => {
            return total +
                (item.preco * item.quantidade);
        },
        0
    );

    const pedido = {
        itens: estadoApp.carrinho.map((item) => {
            return {
                idPrato: item.id,
                nome: item.nome,
                quantidade: item.quantidade,
                subtotal:
                    item.preco * item.quantidade
            };
        }),

        valorTotal,
        status: "Aguardando"
    };

    console.log(
        "Pedido finalizado:",
        JSON.stringify(pedido, null, 2)
    );

    mensagem.textContent =
        `Pedido finalizado! Total: ` +
        `R$ ${valorTotal.toFixed(2)}`;

    estadoApp.carrinho = [];

    atualizarResumoCarrinho();
}

document.addEventListener('DOMContentLoaded', () => {
    carregarCardapio();

        const botaoFinalizar =
            document.getElementById(
                "finalizar-pedido"
            );

        botaoFinalizar.addEventListener(
            "click",
            finalizarPedido
        );
        const formularioCliente = document.getElementById("form-cliente");

        formularioCliente.addEventListener(
            "submit",
            validarFormularioCliente
        );
});