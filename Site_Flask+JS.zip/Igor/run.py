from flask import Flask, render_template
from app.controllers.cardapio_controller import cardapio_bp

app = Flask(__name__, template_folder='app/templates', static_folder='app/static')

# Registra a rota do cardápio
app.register_blueprint(cardapio_bp)

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)